package com.wpl.DAO;

import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import javax.websocket.Session;

import org.springframework.cache.annotation.Cacheable;

import com.wpl.model.Product;
import com.wpl.model.User;

import database.Db_Connection;


public class CartDAO {

	@Cacheable(value ="products")
	public Product getProduct(int id) throws ClassNotFoundException {
		
        String sql = "SELECT * FROM product WHERE product_id = ?";
		
		Connection conn = null;
		
		try { 
			conn = new Db_Connection().getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			Product p = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				p = new Product(
					rs.getInt("product_id"),
					rs.getString("product_name"),
					rs.getFloat("price"),
					rs.getInt("product_qty"),
					rs.getString("image_path")
				);
			}
			rs.close();
			ps.close();
			return p;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	@Cacheable(value ="products")	
public Map<Integer, Product> getProducts() throws ClassNotFoundException {
		
        String sql = "SELECT * FROM product";
		
		Connection conn = null;
		
		try {
			conn = new Db_Connection().getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			Map<Integer,Product> pl = new HashMap<Integer,Product>();
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
			
				
				pl.put(rs.getInt("product_id"),new Product(
						rs.getInt("product_id"),
						rs.getString("product_name"),
						rs.getFloat("price"),
						rs.getInt("product_qty"),
						rs.getString("image_path")
					));
			}
			rs.close();
			ps.close();
			return  pl;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	public boolean placeOrder(Map<Integer,Product> cartMap, HttpSession session) throws ClassNotFoundException {

		boolean flag = false;
		Connection conn = null;
		 try {
			   conn = new Db_Connection().getConnection();
			   PreparedStatement ps = null;
			   List<Product> cartList = new ArrayList<Product>(cartMap.values());
				
				for (Product p : cartList) {
			 	
	            String sql = "INSERT INTO `order` ( user_id, product_id, ordered_qty, total_order_price, order_date, shipping_date) VALUES (?, ?, ?, ?, ?, ?)";

					//String sql = "INSERT INTO `order` ( user_id, product_id, ordered_qty, total_order_price) VALUES (?, ?, ?, ?)";
				    ps = conn.prepareStatement(sql);
               
				Integer s = (Integer) session.getAttribute("user_id");
				if(s != null)
				{
				  ps.setInt(1, s);
				}
				
				ps.setInt(2,p.getProduct_id());
				ps.setInt(3,p.getProduct_qty());
				ps.setFloat(4,p.getPrice()*p.getProduct_qty());

				java.sql.Date logicalDate = new java.sql.Date(System.currentTimeMillis()) ;
				Calendar c = Calendar.getInstance(); 
				c.setTime(logicalDate); 
				c.add(Calendar.DATE, 7);
				
				ps.setDate(5, new java.sql.Date(System.currentTimeMillis()));
				ps.setDate(6, new java.sql.Date(c.getTimeInMillis()));
				if(ps.executeUpdate() > 0)	
	                flag = true;
	            }
				
		            
	                  return flag;
	          
		 
		 }
		 catch (SQLException e) {
	           
	        	throw new RuntimeException(e);
	        
	        } finally {
				if (conn != null) {
					try {
					conn.close();
					} catch (SQLException e) {}
				}
			}
		
	}


   

}
