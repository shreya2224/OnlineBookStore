package com.wpl.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.wpl.model.Order;
import com.wpl.model.Product;
import com.wpl.model.User;

import database.Db_Connection;

public class UserDAO {
	
	 public boolean addUser(User u) throws ClassNotFoundException
	 {
		 
		 Connection conn = null;
		 try {
			 
			    String sql = "SELECT  * FROM  user where user_name = ?";

	            conn = new Db_Connection().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
               ps.setString(1, u.getUser_name());
				
               		
	            ResultSet rs = ps.executeQuery();
	            
	            if(!rs.next())
	            {
	             sql = "INSERT INTO `user` ( user_name, email, `password`, street_address, city, state, mobile_no) VALUES (?, ?, ?, ?, ?, ?, ?)";

	            //conn = new Db_Connection().getConnection();
				 ps = conn.prepareStatement(sql);
                
				ps.setString(1,u.getUser_name());
				ps.setString(2, u.getEmail());
				ps.setString(3, u.getPassword());
				ps.setString(4, u.getAddress());
				ps.setString(5, u.getCity());
				ps.setString(6, u.getState());
				ps.setInt(7, u.getMobile_no());
               		
	            if(ps.executeUpdate() > 0)
	            
	                  return true;
	            }
	            
	          return false; 
	          
		 }
		 catch (SQLException e) {
	           
	        	throw new RuntimeException(e);
	        
	        } finally {
				if (conn != null) {
					try {
					conn.close();
					} catch (SQLException e) {}
				}
			}
	 }
	 
	 public User authenticate(String email, String pass) throws ClassNotFoundException
	 {
		 Connection conn = null;
		 try {
	            String sql = "SELECT  * FROM  user where email = ?";

	            conn = new Db_Connection().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
               ps.setString(1, email);
				
               User u = null;
               		
	            ResultSet rs = ps.executeQuery();
               String db_email, db_pass;
               
               if(rs != null)
               {
	              while (rs.next()) {
	            	  
	            	  u = new User(rs.getInt("user_id"),
		            			rs.getString("user_name"),
		            			rs.getString("email"),
		            			rs.getString("password"),
		            			rs.getString("city"),
		            			rs.getInt("mobile_no")
		            			);
	            	  
	                db_email = rs.getString("email");
	                db_pass = rs.getString("password");

	                
	                    if (pass.equals(db_pass)) {
	                        
	                        //user exists and password is matching
	                        
	                         
	                       // u.setEmail(email);
	                        u.setMessage("Valid User");
	                        
	                      }
	                    else {
	                        
	                        // user exsts but wrong passwotd ask to CHANGE THE PASSWORD
	                    	u.setMessage("Wrong Password");
	                        
	                    }
	                }
               }
	                
	            return u;
	            
	        } catch (SQLException e) {
	           
	        	throw new RuntimeException(e);
	        
	        } finally {
				if (conn != null) {
					try {
					conn.close();
					} catch (SQLException e) {}
				}
			}
	 }

	public Map<Integer,Order> getOrderInfo(HttpSession session) throws ClassNotFoundException {

		Connection conn = null;
		 try {
	            String sql = "SELECT  * FROM  `order` where user_id = ?";

	            conn = new Db_Connection().getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);

				Integer s = (Integer) session.getAttribute("user_id");
				if(s != null)
				{
				  ps.setInt(1, s);
				}
				
				Map<Integer,Order> ol = new HashMap<Integer,Order>();
	            ResultSet rs = ps.executeQuery();
             
              int i = 0;
              if(rs != null)
              {
            	  	while (rs.next()) {
	            	  ol.put(i++, new Order(rs.getInt("order_id"),
		            			rs.getInt("product_id"),
		            			rs.getInt("user_id"),
		            			rs.getFloat("total_order_price"),
		            			rs.getInt("ordered_qty"),
		            			rs.getDate("shipping_date"),
		            			rs.getDate("order_date")
		            			));
	            	  
            	  			}
              }
              
              return ol;
		 } catch (SQLException e) {
	           
	        	throw new RuntimeException(e);
	        
	        } finally {
				if (conn != null) {
					try {
					conn.close();
					} catch (SQLException e) {}
				}
			}
		
	}

	
}
