package com.wpl.model;

import java.sql.Date;

public class Order {
	
	    int order_id;
	    int product_id;
		
		int user_id;
		
		float price;
		
		int product_qty;
		
		Date shippingDate;
		
		Date orderDate;

		

		public Order(int order_id, int product_id, int user_id, float price, int product_qty, Date shippingDate,
				Date orderDate) {
			
			this.order_id = order_id;
			this.product_id = product_id;
			this.user_id = user_id;
			this.price = price;
			this.product_qty = product_qty;
			this.shippingDate = shippingDate;
			this.orderDate = orderDate;
		}

		public int getOrder_id() {
			return order_id;
		}

		public void setOrder_id(int order_id) {
			this.order_id = order_id;
		}

		public int getProduct_id() {
			return product_id;
		}

		public void setProduct_id(int product_id) {
			this.product_id = product_id;
		}

		public int getUser_id() {
			return user_id;
		}

		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}

		public float getPrice() {
			return price;
		}

		public void setPrice(float price) {
			this.price = price;
		}

		public int getProduct_qty() {
			return product_qty;
		}

		public void setProduct_qty(int product_qty) {
			this.product_qty = product_qty;
		}

		public Date getShippingDate() {
			return shippingDate;
		}

		public void setShippingDate(Date shippingDate) {
			this.shippingDate = shippingDate;
		}

		public Date getOrderDate() {
			return orderDate;
		}

		public void setOrderDate(Date orderDate) {
			this.orderDate = orderDate;
		}
		
		

}
