package com.wpl.model;




public class Product {
	
	
    int product_id;
	
	String product_name;
	
	float price;
	float product_cost;
	
	int product_qty;

	String imagePath;
	
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public void makeCopy(Product p)
	{
		this.product_id = p.getProduct_id();
		this.product_name = p.getProduct_name();
		this.price = p.getPrice();
		this.product_qty = p.getProduct_qty();
		//this.product_cost = (float) (p.getProduct_qty() * 1.0 * p.getPrice());
		this.imagePath = p.getImagePath();	
	}
/*	public void update_total_cost()
	{
		this.product_cost = (float) (this.getPrice() * 1.0 * this.getProduct_qty());
	} */
	
	public Product(int product_id, String product_name,float price, int product_qty, String imagePath) {
		
		this.product_id = product_id;
		this.product_name = product_name;
		this.price = price;
		this.product_qty = product_qty;
		this.imagePath = imagePath;
	//	this.product_cost = (float) (price * 1.0 * product_qty);
	//	System.out.println("product_cost = "+product_cost);
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getProduct_qty() {
		return product_qty;
	}

	public void setProduct_qty(int product_qty) {
		this.product_qty = product_qty;
	}

	
}
