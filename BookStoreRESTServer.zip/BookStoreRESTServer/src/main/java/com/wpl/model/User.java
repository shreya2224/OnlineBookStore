/**
 * 
 */
package com.wpl.model;

/**
 * @author Praful
 *
 */
public class User {

	int User_id;
	String User_name;
	String Email;
	String Password;
	String Address;
	String City;
	String State;
	int Mobile_no;
	String message;
	
	
	
	public User(int user_id, String user_name, String email, String password, String city, int mobile_no) {
		//super();
		User_id = user_id;
		User_name = user_name;
		Email = email;
		Password = password;
		City = city;
		Mobile_no = mobile_no;
	}
	public User() {
		
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getUser_id() {
		return User_id;
	}
	public void setUser_id(int user_id) {
		User_id = user_id;
	}
	public String getUser_name() {
		return User_name;
	}
	public void setUser_name(String user_name) {
		User_name = user_name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getMobile_no() {
		return Mobile_no;
	}
	public void setMobile_no(int mobile_no) {
		Mobile_no = mobile_no;
	}
	

}
