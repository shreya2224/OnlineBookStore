package com.wpl.controller;

import java.sql.ResultSet;
import java.util.Collection;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wpl.DAO.CartDAO;
import com.wpl.DAO.UserDAO;
import com.wpl.model.Order;
import com.wpl.model.Product;
import com.wpl.model.User;

@RestController
@RequestMapping("/user/*")
public class UserController {
	
	private static Map<Integer,Order> orderMap;
	
	 @RequestMapping(value = "/getOrderDetails", method=RequestMethod.GET )
	   public ResponseEntity<Collection<Order>> getOrderDetails(HttpSession session) throws ClassNotFoundException {
	      
		UserDAO ud = new UserDAO();
		 
	         return new ResponseEntity<Collection<Order>>(ud.getOrderInfo(session).values(), HttpStatus.OK);
		  
			 // return new ResponseEntity<ResultSet>(HttpStatus.NO_CONTENT); 
	   }
	
	@RequestMapping(value = "/checkUser", method=RequestMethod.POST)
	   public ResponseEntity<User> checkUser(@RequestBody User uk, HttpSession session) throws ClassNotFoundException {
	      
		
		UserDAO ud = new UserDAO();
		 User u = ud.authenticate(uk.getEmail(), uk.getPassword());
		  
		 if(u != null)
		 {
		  if(u.getMessage().equalsIgnoreCase("Valid User"))
		  {
			  session.setAttribute("user_id" , u.getUser_id());
	         return new ResponseEntity<User>(u, HttpStatus.OK);
		  }
		  else
			  if(u.getMessage().equalsIgnoreCase("Wrong Password"))
			         return new ResponseEntity<User>(HttpStatus.UNAUTHORIZED);
		 }
		
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND); 
	   }
	
	@RequestMapping(value = "/addUser", method=RequestMethod.POST)
	   public ResponseEntity<User> addUser(@RequestBody User uk) throws ClassNotFoundException {
		
		UserDAO ud  = new UserDAO();
		
		if(ud.addUser(uk))
		{
			return new ResponseEntity<User>(uk, HttpStatus.OK);
		}
		
		return new ResponseEntity<User>(uk, HttpStatus.CONFLICT);
		
	}

	
}
