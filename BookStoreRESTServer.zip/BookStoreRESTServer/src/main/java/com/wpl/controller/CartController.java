package com.wpl.controller;

import com.wpl.DAO.CartDAO;
import com.wpl.DAO.UserDAO;
import com.wpl.model.Product;
import com.wpl.model.User;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import java.util.Collection;
import java.util.HashMap;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cart/*")
public class CartController {

	//private static int itemcount;
	private static Map<Integer,Product> cartMap;
	private static Map<Integer,Product> pl;
	private static final Logger logger = Logger.getLogger(CartController.class);
	
	
	@RequestMapping(value = "/getSession", method=RequestMethod.GET)
	   public ResponseEntity<Integer> getSession(HttpSession session) throws ClassNotFoundException {
		
		Integer s = (Integer) session.getAttribute("user_id");
		return new ResponseEntity<Integer>(s, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/checkout", method=RequestMethod.GET)
	   public ResponseEntity checkout(HttpSession session) throws ClassNotFoundException {
		
		CartDAO ud  = new CartDAO();
		
		if(ud.placeOrder(cartMap,session))
		{
			return new ResponseEntity(HttpStatus.OK);
		}
		
		return new ResponseEntity(HttpStatus.BAD_REQUEST);
		
	}
	//
	@RequestMapping(value="/getProductlist", method=RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Product>> getProductlist() throws ClassNotFoundException{

		
		CartDAO cd = new CartDAO();
		
		pl = new HashMap<Integer,Product>();;
		pl = cd.getProducts();
		
		
		
		return new ResponseEntity<Collection<Product>>(pl.values(), HttpStatus.OK);
       // return bl;

	}
	//
	@RequestMapping(value = "/searchproduct/{id}", method=RequestMethod.GET)
	   public ResponseEntity<Product> getProductByID(@PathVariable int id) throws ClassNotFoundException {
	      
		CartDAO cd = new CartDAO();
		Product bk =  cd.getProduct(id);
	      
	      return new ResponseEntity<Product>(bk, HttpStatus.OK);
	   }
	
	@RequestMapping(value="/getAvailableProducts", method=RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Product>> getAvailableProducts() throws ClassNotFoundException{

		
	if(pl != null)
		return new ResponseEntity<Collection<Product>>(pl.values(), HttpStatus.OK);
       
	else
		return new ResponseEntity<Collection<Product>>(HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(value="/addToCart/{id}",method = RequestMethod.GET)
	public ResponseEntity<Product> addToCart(@PathVariable int id) throws ClassNotFoundException, CloneNotSupportedException{
	   
		if(cartMap == null)
		{
			cartMap = new HashMap<Integer,Product>();
			
		}
		
		Product bk = null;
		
		if(pl.containsKey(id))
		{
			
			int q = pl.get(id).getProduct_qty();
			
	    
				if(q == 0)
				{
					return new ResponseEntity<Product>(HttpStatus.IM_USED);
				}
				else
				{
					pl.get(id).setProduct_qty(q-1);
					
				     bk = new Product();
				  //  bk.makeCopy(pl.get(id));
				    
					if(cartMap.containsKey(id))
					{
						int items = cartMap.get(id).getProduct_qty() + 1;
						cartMap.get(id).setProduct_qty(items);
					//	cartMap.get(id).update_total_cost();
						bk = cartMap.get(id);
					}
					else
					{
				      bk.makeCopy(pl.get(id));
					  bk.setProduct_qty(1);
					//  bk.update_total_cost();
				      cartMap.put(id, bk);
					}
					
				}
		}
	      return new ResponseEntity<Product>(bk, HttpStatus.OK);
	 }
	
	
	@RequestMapping(value="/deleteItem/{id}",method = RequestMethod.GET)
	public ResponseEntity<Product> deleteItem(@PathVariable int id) throws ClassNotFoundException{
		   
		CartDAO cd = new CartDAO();
		
		if(pl.containsKey(id))
		{
			int q = cartMap.get(id).getProduct_qty();
			
			pl.get(id).setProduct_qty(pl.get(id).getProduct_qty()+q);
		}
	     // cartMap.remove(id, bk);
		 Product bk = cartMap.get(id);
	      cartMap.remove(id);
	      return new ResponseEntity<Product>(bk, HttpStatus.OK);
	   }
	
	@RequestMapping(value="/updateItem/{id}/{quantity}",method = RequestMethod.GET)
	public ResponseEntity<Product> updateItem(@PathVariable int id, @PathVariable int quantity) throws ClassNotFoundException{
		   
		CartDAO cd = new CartDAO();
		
		if(pl.containsKey(id))
		{
			int lq = pl.get(id).getProduct_qty();
			int cq = cartMap.get(id).getProduct_qty();
			
			
			if((lq+cq) < quantity)
				return new ResponseEntity<Product>(HttpStatus.NOT_MODIFIED);
			else
			{
			  int diff = quantity - cq;	
			  cartMap.get(id).setProduct_qty(quantity);
			  pl.get(id).setProduct_qty(pl.get(id).getProduct_qty()-diff);
			}
		}
	    
		 Product bk = cartMap.get(id);
	      
	      return new ResponseEntity<Product>(bk, HttpStatus.OK);
	   }
	
	@RequestMapping(value="/getCartItems", method=RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Product>> listCartItems() throws ClassNotFoundException{

		
		Collection<Product> pl = cartMap.values();
		
		return new ResponseEntity<Collection<Product>>(pl, HttpStatus.OK);
      
	}
 
	
	
}

