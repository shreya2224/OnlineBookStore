package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@Configuration
@ComponentScan(basePackages = { "com.example","com.wpl.controller","com.wpl.DAO", "com.wpl.model", "database","filter"})
@EnableAutoConfiguration
@SpringBootApplication
@EnableCaching
public class BookStoreRestServerApplication {

    public static void main(String[] args) {
    	
    	SpringApplication.run(BookStoreRestServerApplication.class, args);
    }
    
    @Bean
    public CacheManager cacheManager()
    {
    	ConcurrentMapCacheManager cacheManager = new ConcurrentMapCacheManager("products");
    	
    	return cacheManager;
    	
    }
}

