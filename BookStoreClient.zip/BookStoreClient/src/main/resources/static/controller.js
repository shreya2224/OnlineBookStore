
function books($scope, $http) {
    $http.get('http://localhost:9000/api/v1/books').
        success(function(data) {
            $scope.books = data;
        });
    
    $scope.getBook = function() {
        
        $http.get('http://localhost:9000/api/v1/book/'+$scope.bookid).
        success(function(data) {
            $scope.onebook = data;
        });
      };
}
