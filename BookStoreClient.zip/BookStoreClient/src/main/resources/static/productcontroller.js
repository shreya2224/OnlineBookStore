
function products($scope, $http) {
	//window.alert("hello");
    $http.get('https://localhost:8100/cart/getProductlist').
        success(function(data) {
        	
            $scope.books = data;
            
            
        });
    
    
    $http.get('https://localhost:8100/cart/getCartItems').
  	success(function(data){
  		$scope.dispitem = data;
  	});
    
    
    $scope.getBook = function() {
        
        $http.get('https://localhost:8100/cart/searchproduct/'+$scope.productid).
        success(function(data) {
            $scope.onebook = data;
            
        });
      };
      
      
  	var sum={};
$scope.add_item1 = function(param, cost){
	     // sum.tot_sum=sum+cost;
	     // window.alert('Total Cost: '+ tot_sum);
    	  $http.get('https://localhost:8100/cart/addToCart/'+param).
  		success(function(data){
  			$scope.additem1 = data;
  			
  		});
  		
  	};
  	
  	//sum1 = this.tot_sum;
  	
  	$scope.del_item = function(param, cost){
  		sum1 = sum.tot_sum-cost;
  		window.alert(sum1);
  		$http.get('https://localhost:8100/cart/deleteItem/'+param).
  		success(function(){	
  			
  		});
  		
  	};
  	
//  	function showcart($scope, $http){
//  		window.alert("hello");
//  	$http.get('https://localhost:8100/cart/getCartItems').
//  	success(function(data){
//  		$scope.hello = "h";
//  		$scope.dispitem = data;
//  	});
  	
//  	};
  	
  	
      
}
