function users_work($scope, $http){
	
	$scope.userlogin = function(){
  	  $http({
  		  method:'post',
      	  url : 'https://localhost:8100/user/checkUser',
      	  data : {"email":"kkl@gmail.com","password":4567}, 
  	      headers: {'Accept': 'application/json','Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'}
  	      }).
  	      success(function(){
  		  window.alert("yo world");
  	  });
  	  };
  	  
  	
  	$scope.userlogin1 = function(){
      
  		var data = $.param({
  		email: $scope.email,
  		password: $scope.password
  		});


  		$http.post('https://localhost:8100/user/checkUser',data, config).success(function(data,status,headers,config){

  		$scope.ServerResponse  = data;
  		});


  		};
	
	
	$scope.add_user = function(){
		var vm = this;
		$http.post('https://localhost:8100/user/addUser')
		
	};
	
	
}